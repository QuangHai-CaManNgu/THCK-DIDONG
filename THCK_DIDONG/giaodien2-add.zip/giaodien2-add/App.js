import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, ScrollView, TextInput, StyleSheet, Alert } from 'react-native';

export default function BikeShop() {
  // State quản lý danh sách xe và thông tin form nhập liệu
  const [bikes, setBikes] = useState([
    { name: 'Pinarello', price: 1800, image: 'https://api.xedap.vn/wp-content/uploads/2023/08/XF275_BlackRed.jpg', highlight: true },
    { name: 'Pina Mountai', price: 1700, image: 'https://thongnhat.com.vn/wp-content/uploads/2023/10/thong-nhat-mtb-26-02-do-e1708922092858.jpg.webp' },
    { name: 'Pina Bike', price: 1500, image: 'https://api.xedap.vn/wp-content/uploads/2024/01/DM_20241003182344_001.jpg' },
    { name: 'Pinarello', price: 1900, image: 'https://api.xedap.vn/wp-content/uploads/2024/10/Single2_Green.jpg' },
    { name: 'Pinarello', price: 2700, image: 'https://api.xedap.vn/wp-content/uploads/2024/01/M137_CreamGrayBlue.jpg', highlight: true },
    { name: 'Pinarello', price: 1350, image: 'https://api.xedap.vn/wp-content/uploads/2024/10/PS06_Grey-1.jpg' },
  ]);

  const [newBike, setNewBike] = useState({
    name: '',
    price: '',
    image: '',
  });

  // Hàm thêm xe mới
  const handleAddBike = () => {
    const { name, price, image } = newBike;
    if (!name || !price || !image) {
      Alert.alert('Error', 'Please fill all the fields');
      return;
    }
    setBikes([...bikes, { ...newBike, price: parseFloat(price) }]); // Thêm xe mới vào danh sách
    setNewBike({ name: '', price: '', image: '' }); // Reset form
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>The world’s Best Bike</Text>

      {/* Form thêm xe mới */}
      <View style={styles.addForm}>
        <TextInput
          style={styles.input}
          placeholder="Bike Name"
          value={newBike.name}
          onChangeText={(text) => setNewBike({ ...newBike, name: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Price"
          value={newBike.price}
          keyboardType="numeric"
          onChangeText={(text) => setNewBike({ ...newBike, price: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Image URL"
          value={newBike.image}
          onChangeText={(text) => setNewBike({ ...newBike, image: text })}
        />
        <TouchableOpacity style={styles.addButton} onPress={handleAddBike}>
          <Text style={styles.addButtonText}>Add Bike</Text>
        </TouchableOpacity>
      </View>

      {/* Tab chọn lọc */}
      <View style={styles.tabContainer}>
        <TouchableOpacity style={[styles.tab, styles.activeTab]}>
          <Text style={styles.tabTextActive}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tab}>
          <Text style={styles.tabText}>Roadbike</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tab}>
          <Text style={styles.tabText}>Mountain</Text>
        </TouchableOpacity>
      </View>

      {/* Danh sách xe */}
      <ScrollView contentContainerStyle={styles.bikeGrid}>
        {bikes.map((bike, index) => (
          <View key={index} style={[styles.bikeCard, bike.highlight && styles.highlightBorder]}>
            <Image source={{ uri: bike.image }} style={styles.bikeImage} />
            <Text style={styles.bikeName}>{bike.name}</Text>
            <Text style={styles.bikePrice}>${bike.price}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f7f0f3',
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#e91e63',
    marginBottom: 16,
    textAlign: 'center',
  },
  addForm: {
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#6200ea',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 16,
  },
  tab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 5,
    backgroundColor: '#f2f2f2',
    marginHorizontal: 15,
  },
  activeTab: {
    backgroundColor: '#ffdada',
  },
  tabText: {
    color: '#333',
    fontSize: 14,
  },
  tabTextActive: {
    color: '#e91e63',
    fontSize: 14,
    fontWeight: 'bold',
  },
  bikeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  bikeCard: {
    width: '48%',
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 10,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
    elevation: 3,
  },
  highlightBorder: {
    borderWidth: 2,
    borderColor: '#6200ea',
  },
  bikeImage: {
    width: '100%',
    height: 100,
    resizeMode: 'contain',
    marginBottom: 8,
  },
  bikeName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  bikePrice: {
    fontSize: 16,
    color: '#e91e63',
  },
});
