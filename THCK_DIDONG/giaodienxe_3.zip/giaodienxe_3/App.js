import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const ProductCard = () => {
  return (
    <View style={styles.card}>
      {/* Image Section */}
      <Image 
        source={{ uri: 'https://bizweb.dktcdn.net/thumb/1024x1024/100/412/747/products/calli-1600.jpg?v=1726819404370' }} // Replace with actual image URL
        style={styles.image} 
      />

      {/* Product Information */}
      <View style={styles.infoContainer}>
        <Text style={styles.productName}>Pina Mountain</Text>

        {/* Price and Discount Section */}
        <View style={styles.priceSection}>
          <Text style={styles.discount}>15% OFF | 350$</Text>
          <Text style={styles.originalPrice}>449$</Text>
        </View>

        {/* Description */}
        <Text style={styles.description}>
          It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.
        </Text>

        {/* Add to Cart Button */}
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Add to cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 15,
    shadowColor: '#faebd7',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  image: {
    width: '100%',
    height: 170,
    borderRadius: 10,
  },
  infoContainer: {
    marginTop: 10,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  priceSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  discount: {
    color: '#d9534f',
    fontSize: 16,
    marginRight: 10,
  },
  originalPrice: {
    fontSize: 16,
    textDecorationLine: 'line-through',
    color: '#999',
  },
  description: {
    fontSize: 14,
    color: '#666',
    marginTop: 30,
  },
  button: {
    backgroundColor: '#ff6347',
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginTop : 90,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProductCard;
