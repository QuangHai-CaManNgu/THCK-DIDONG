import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function PowerBikeShop() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>
          A premium online store for sporter and their stylish choice
        </Text>
      </View>
      
      <View style={styles.imageContainer}>
        <Image
           source={require('./assets/xe xanh.png')} // Đường dẫn tới hình ảnh trong thư mục assetsReplace with actual image URL
          style={styles.image}
        />
      </View>
      
      <Text style={styles.title}>POWER BIKE SHOP</Text>
      
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f0f3',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    borderColor: '#ff00ff',
    borderWidth: 2,
    borderRadius: 10,
  },
  header: {
    backgroundColor: '#e0f0e9',
    padding: 8,
    borderRadius: 5,
    marginBottom: 16,
  },
  headerText: {
    textAlign: 'center',
    color: 'black',
    fontSize: 14,
    fontWeight: '500',
  },
  imageContainer: {
    borderWidth: 2,
    borderColor: '#E941411A',
    borderRadius: 10,
    padding: 10,
    marginBottom: 16,
  },
  image: {
    width: 200,
    height: 150,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 16,
  },
  button: {
    backgroundColor: '#ff4c4c',
    paddingVertical: 10,
    paddingHorizontal: 60,
    borderRadius: 20,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
